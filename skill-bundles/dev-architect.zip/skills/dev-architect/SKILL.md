---
name: dev-architect
allowed-tools: Bash, Read, Grep, Glob, Write, Edit, Agent, AskUserQuestion, WebSearch, WebFetch
description: "Run /dev-architect after /dev-scope to settle how the product gets built. Weighs options and settles the stack layer by layer, records the person's choices beside its recommendations, writes the local development containers, and on a codebase that already exists settles whether features already built appear in the plan, then audits it for outdated or vulnerable packages and finds the MCP servers and skills that fit. Writes the architecture and planning documents into .konteksto/. On a project with a frontend, /dev-design designs the surfaces afterwards."
---

## Output style (plain words, no dashes, no hyphens)

<!-- OUTPUT-STYLE:START -->
Write everything this skill produces, files and messages alike, in plain simple language. Keep technical terms that carry real meaning; explain each in plain words. Never use a dash or a hyphen as punctuation: no em dash, no en dash, and no hyphenated compounds. Write `read only`, not `read-only`. Say it in simple words, or reword the sentence. Code, file paths, command flags, and values other skills match on keep their hyphens. A structural separator inside a template format other skills parse, such as the em dash in `## Phase 1 — <NAME>`, is part of that format: reproduce it exactly, since changing it breaks the mirroring. Use short sentences, commas, or parentheses. Clear beats clever.
<!-- OUTPUT-STYLE:END -->

## What this skill does

Answers **how the product gets built**, given a `project-overview.md` that already says what it is. Settles every load bearing technical decision and records the result across the documents in `.konteksto/`.

`/dev-scope` owns the what and never names a tool. **This skill makes every tool call there is**, including installing the browser `/dev-design` and `/dev-check verify` need.

**How the product looks is `/dev-design`'s**, on a project with an `app/`. It owns `design.md`, `design-registry.md`, and the prototypes, and nothing here writes any of them.

## Where this sits

**Before this:** `/dev-scope`, which settled what the product is.

**After this:** `/dev-design` on a project with an `app/`, which designs every surface the flows require and gets each one approved. On a backend with no `app/`, straight to `/dev-develop`, which builds the first real task in the plan, meaning the first one outside a Phase 0 of baseline rows where the plan has one.

The whole chain, once per project then once per task:

```
/dev-scope  →  /dev-architect  →  /dev-design  →  /dev-develop  →  /dev-check verify  →  /dev-test
```

`/dev-debug` when verify fails. `/dev-check review`, `/dev-document pr`, and `/dev-sync` before a merge.

## Artifact ownership

The documents below, all created and updated by this skill only, filled from the matching template in `templates/`, which lives in this skill's own folder.

**One shared record sits beside them.** `.konteksto/human-decisions.md` is created by `/dev-scope` and appended to by this skill for requirements, data, stack, standards, tooling, risk, and architecture acceptance choices the person makes. Preserve the question, every option, the recommendation marker, and their selected option in the format that file defines. `/dev-design` is its third and final writer.

**No count appears anywhere in these instructions, deliberately.** A number written beside a list that later grows is wrong the first time somebody adds to it, and it had already gone wrong twice here before anybody noticed. The list is the list.

**Stage 1, the foundation.** What the system is made of.

| Order | Document | Depends on |
| --- | --- | --- |
| 1 | `architecture.md` | the pages and flows in `project-overview.md` |
| 2 | `tooling.md` | the Stack table in `architecture.md` |
| 3 | `code-standards.md` | the Stack table |
| 4 | `library-docs.md` | the approved dependency list in `code-standards.md` |

**Stage 2, the plan.** Turns the foundation into an ordered build. Starts once every Stage 1 artifact is approved.

| Order | Document | Depends on |
| --- | --- | --- |
| 5 | `build-plan.md` | Features in Scope, plus every build affecting commitment in the architecture |
| 6 | `progress-tracker.md` | the exact phases, tasks, and goals in `build-plan.md` |
| 7 | `decision-log.md` | nothing, it starts empty |
| 8 | `ui-registry.md` | the component rules in `code-standards.md` |

**The plan does not wait on any design.** `/dev-design` runs after this skill, and a surface with no approved prototype blocks its own task rather than the plan. Write the whole plan regardless.

Never touch `project-overview.md`. It is `/dev-scope`'s file. If this work proves it wrong, say so and ask the user to run `/dev-scope` again rather than editing it yourself.

**`glossary.md` is the one exception, and a narrow one.** `/dev-scope` creates it, and you are its second writer. Read it before the design conversation, name everything you write with its words, and add to it only in these two cases:

- **A concept the design brought into existence** that the product conversation had no word for. A join table's row is not one. A thing a user would name in a sentence is.
- **A definition the schema proved imprecise**, most often one word that turned out to be covering two concepts.

**You may sharpen a definition and you may not rename a term.** A rename is a decision about the product's own language, and it belongs to the person whose product it is. Where a term is genuinely wrong, say so and ask.

**No implementation words go in, ever.** Not a table, a type, a field, an endpoint, or a library. That file has to survive a rewrite that changes every one of them. Its What does not belong here and Who writes what sections state the rest, and they stay as they are.

**`design.md`, `design-registry.md`, and `.konteksto/designs/` are `/dev-design`'s, and you write none of them.** Not a row, not a status, not a line of a prototype, and not on the first run when none of them exists yet. A design need that turns out to be a technical decision comes back here; the design itself never does.

**Three of these are living files, created here and updated elsewhere.** `progress-tracker.md`, `decision-log.md`, and `ui-registry.md` are written once by this skill, in their starting state, and every update after that belongs to another skill: task and subtask Status cells and a new component section to `/dev-develop`, task and subtask Verify Check cells to `/dev-check verify`, and Decision or Evidence rows to `/dev-develop`, `/dev-check`, or `/dev-debug`. Do not stamp a task or subtask, register a component, or log an event for something that does not exist yet.

Read a template from `templates/`, in this skill's folder, and write the filled copy to `.konteksto/<same-file-name>`. Never edit a template in place.

## Guardrails

Do NOT write application code, scaffold a project, or install a package the product itself ships. This skill produces documents and settles decisions. Building starts as a separate, later request.

Some narrow exceptions, and each one states its own edges. Agent tooling found in step 6, meaning skills and MCP servers, may be set up during this skill, but only per the consent rules in that step, and only for a tool the user approved by name. `docker-compose.yml` plus `.env.example` are written in step 5, because they are the structure the build sits in rather than the product itself.

**Playwright and its browser may be installed**, on a project with an `app/`. **You install it and you never use it**, which looks odd until you remember the rule it protects: this skill makes every tool call, so a skill that needed a browser and installed its own would put a second tool caller in the system. `/dev-design` cannot review a design without one and `/dev-check verify` cannot screenshot a breakpoint without one, and both read what you recorded rather than reaching for a package manager.

Say what you are installing and why before you install it. It is a development tool for reviewing and verifying rather than a package the product ships, so it never enters `library-docs.md`. It is recorded in the Visual verification section of `tooling.md` like every other tool the agent works with.

**Prove it works before you record it, and a project that already has Playwright gets proved the same way.** An install that returned zero is not a browser that launches, and an existing end to end suite is not a visual verification setup: it may be on a language binding this harness cannot import, or on a machine where the browser binary was never downloaded. The Check row of that section names the command, and it is `/dev-design`'s own preflight probe. Run it here, once, rather than leaving a person to find the problem while they are waiting to approve a design.

Do NOT fill a document with a guess. Every value is read from the existing codebase, stated by the user, found at a source you actually fetched, or picked by the user from options you presented.

Do NOT let a document look simple enough to skip. A one page tool still needs its stack recorded. The document can be short. It cannot be absent.

## Asks vs acts

- **INFER**: anything `project-overview.md` or the existing codebase already settles. The platform, whether there is a UI layer, an already chosen provider, the shape of the data. Derive it and confirm in one line.
- **ASK**: only what the user alone knows. Hosting constraints, existing accounts and contracts, compliance scope, team familiarity, budget.
- **RECOMMEND**: anything expertise settles. Which framework, which database, which pattern. Make the call, give a one line why, name the runner up. Never a neutral menu, never a silent decision.

Recommendations build on what the project already uses. If the codebase is already on a platform, prefer that platform's own auth and storage over adding an external tool. Reuse beats sprawl.

**That is the intent, not the procedure.** How to actually run the questioning, stage by stage, what to grill on, and what to infer rather than ask, lives in `internal/design-conversation.md`. The Execution section below makes you read it in full before you ask a single design question.

## Decision panels

Every user facing choice is an options panel: 2 to 4 concrete options real to this project, exactly one marked as recommended with a one line why. Use `AskUserQuestion` where available, otherwise the same options as plain text. Ask in rounds of up to 4 related questions.

The full mechanics, including the free text slot, generating options fresh rather than from a canned list, and never bundling a whole decision into one panel, are in `internal/design-conversation.md`.

**Record every answered panel that settles durable project intent.** Immediately after the answer, append one entry to `.konteksto/human-decisions.md` in the format that file defines. Do not reconstruct a batch at the end. Do not record an inference, the recommendation you formed yourself, a permission prompt, or a routine choice about running a tool.

## Execution

### Step 1: Pre flight

- **Read `.konteksto/project-overview.md` in full.** If it does not exist, stop and tell the user to run `/dev-scope` first. Everything here depends on it.
- **Read `.konteksto/glossary.md` in full, and use its words from here on.** Every table, boundary, component, and phase name you write comes out of it, because a schema that renames the product's concepts forces every later reader to translate, and eventually one of them translates wrongly. Where the file is missing on a project that has a `project-overview.md`, say so and write it from the terms already in that file rather than proceeding without one.
- **Read `.konteksto/human-decisions.md` in full.** It prevents this conversation from asking the person to settle something they already chose, and makes a deliberate override of an earlier recommendation visible before you form a new one. On an upgraded project where the file is missing, read `../dev-scope/templates/human-decisions.md` and create an empty copy before the first panel. Never reconstruct old questions or recommendation markers from the resulting architecture documents.
- **Read what `/dev-scope` handed you**, if anything: whether a codebase exists, the stack it showed, and any tool or constraint the user named during scoping. Do not survey the same ground again.
- **Work out whether the code is actually somebody else's.** A manifest and a source tree are not proof of an existing codebase, because `/dev-develop` scaffolds this project itself as the first task in the plan. Code whose stack matches what `.konteksto/architecture.md` already specifies is **our own scaffold**, and it is not brownfield. Only code with no matching documents, or code that diverges from them, is a real existing codebase.
- **If a real codebase exists and you were not handed a survey**, read it now: the directory tree, every package manifest, the lint and build config, the entry points. The stack that is already there is a decision already made. Record it, do not re litigate it.
- **Check `.konteksto/` for existing documents.** Report which of the expected artifacts are present. Never overwrite one silently; ask whether to update in place or start over. **Say what is in `designs/` and leave it alone**, since it is `/dev-design`'s and an approved prototype is never overwritten by anybody.

### Step 2: Run the design conversation

**This is a hard gate. Read `internal/judgment.md` and `internal/design-conversation.md` in full before you ask the user a single design question, and follow both.**

`judgment.md` is the judgment you bring: the posture, the failure patterns to name on sight, and the instruction to **challenge the premise before designing anything**. `design-conversation.md` is the procedure. A perfectly run interview that arrives at the wrong stack has helped nobody, which is why the judgment file is read first.

It holds the already built check, the framing, the dimension enumeration, the question mechanics, the six stages, and the completeness gate that decides when the questioning is finished. Do not open the interview, generate questions, or write any document until you have read it.

Steps 2 through 6 here are the outline. That file is the protocol.

**How the two line up.** Everything from here to step 6 is one continuous conversation, not five separate phases with pauses between them:

| Conversation stage | Where it is spelled out |
| --- | --- |
| Framing, and the already built check | `internal/design-conversation.md` |
| Stage A, requirements | `internal/design-conversation.md` |
| Stage B, the data model | `internal/design-conversation.md` |
| Stage C, the stack walk | step 2 below |
| The adoption baseline | step 2a below, existing codebases only |
| Stage D, interfaces and value sourcing | `internal/design-conversation.md` |
| Stages E and F, security and edge cases | `internal/design-conversation.md` |
| The brownfield audit | step 4 below |
| Containers and data lifecycle | step 5 below |
| Tooling discovery | step 6 below |

Nothing except a newly answered entry in `human-decisions.md` gets written until the completeness gate in that file passes. Each human answer is appended immediately, because losing the session must not lose which options the person rejected.

#### Settle the stack

Read the Project Shape section of `project-overview.md` first. It says whether the product is frontend only, backend only, or both, and it fixes the folder layout. Ask stack questions only for the halves that exist. Never ask which database a frontend only project uses.

Walk every layer that half needs:

- **Client**, when `app/` exists: language, framework, routing, styling or UI kit, state handling.
- **Server**, when `backend/` exists: language, framework, data storage, migrations, auth and sessions.
- **Anything the flows imply**, either half: payments, transactional email, file storage, search, caching, queues, background work, realtime.

**Read `internal/stack-defaults.md` before the first stack question.** It holds the pattern to settle before any technology, the default category per layer, and the opinions to apply. Its central rule: **reason in the durable category, then pick the current product fresh**, because the category stays true and the product name rots.

Settle the **pattern** first, meaning one application or several, from the scale and team size. Choosing a framework before that is answering before understanding the question.

For each layer not already fixed by the existing codebase or named by the user, present a panel with 2 or 3 real options, their trade offs, and your recommendation. **Always include the simplest option**, described honestly rather than as a straw man. Name real tools here. This is the one place in the workflow where that happens. Only the picked option goes into a document.

Record each pick and its reason in the "Why these choices" list in `architecture.md`.

The stack is settled when every layer of every existing half has a named tool. Do not start step 3 before that.

Stages A, B, D, E, and F of the design conversation happen here too, not only the stack walk. The data model is elicited and confirmed, and the value sourcing loop is closed. Both are in `internal/design-conversation.md`, and skipping either produces a document set `/dev-develop` cannot build from.

### Step 2a: Settle the adoption baseline

**Skip this step entirely on a fresh project, and on our own scaffold.** It applies only when step 1 found a real existing codebase.

Otherwise **read `internal/adoption-baseline.md` and follow it.** It asks one question and nothing else: whether the features that are already built appear in the plan. The default is no.

**The other half of this belongs to `/dev-design`**, which asks whether surfaces that already exist owe prototypes, next to the registry that answer governs. **Do not ask it here**, and do not assume the answer given here applies there. They are two decisions with two defaults, and a user who wants their shipped screens left alone may still want the plan to list what is built.

The answer is written later, in step 8. Carry it forward with the step 4 findings rather than writing early.

### Step 3: Confirm there is a design owner, and do not become one

**Skip this whole step when there is no `app/`.** A backend has no surfaces.

Otherwise there is exactly one thing to do here, and it is not designing anything.

**Confirm the Visual verification section of `tooling.md` will be filled**, per step 5's tooling work and step 7's writing, with a browser automation tool, its install command, and the check command that proves both the tool and its browser work. `/dev-design` renders every prototype at every breakpoint and every state and cannot start without one, and `/dev-check verify` cannot produce a screenshot without one. **On a project with an `app/` that section is required rather than optional.**

**Finding Playwright already in the project does not finish this.** It is a reason the install will be quick, not evidence that a review can run: `/dev-design` runs a probe before every session and routes straight back here when it fails. Run that probe once now, and record what it said.

**You do not map surfaces, settle a design system, write a prototype, or touch `design-registry.md`.** All of it belongs to `/dev-design`, including on the very first run when none of those files exists. A stack conversation that drifts into deciding what the dashboard looks like has created design intent that nobody designed and nobody approved.

**A missing design never holds up this skill's work.** Write the whole plan regardless: a surface with no approved prototype blocks its own task, not the project.

**Name `/dev-design` as the next step in your report**, whenever `app/` exists. It is the one handoff a user can miss, and missing it produces a project with a build plan, no designs, and a first UI task that blocks for reasons nobody expects.

### Step 4: Audit an existing codebase

**Skip this step entirely on a fresh project, and on our own scaffold.** It applies only when step 1 found code this workflow did not generate.

Otherwise **read `internal/brownfield-audit.md` and follow it.** It confirms the project structure, settles what happens to existing components, and audits every dependency for age, abandonment, and known vulnerabilities.

The rule worth carrying from here: **a vulnerable dependency is recommended plainly, not offered as one option among equals**, and a declined update is recorded as an accepted risk rather than forgotten.

### Step 5: Local development containers

Run this once the stack is settled. Every service the stack named needs somewhere to run locally, and a compose file is how this project structures that.

#### Propose the services

Derive the service list from the stack, never from a fixed menu:

- **One service per stored data store** picked in step 2, for example Postgres, MySQL, or Redis.
- **One service per half that exists**, building from `backend/Dockerfile.dev` and `app/Dockerfile.dev`.
- **A local stand in for every external service the flows need**, so the build never depends on a real account. Mail becomes MailHog or Mailpit. S3 style file storage becomes MinIO. Name the real service it stands in for, so nobody ships the stand in.
- **An admin interface only when asked for.** A database console is convenience, not structure.

Present the list as one panel with your recommendation, and say plainly which ones you would leave out. The user can decline any service, and can decline Docker entirely. A no is a complete answer. Record a decline in `tooling.md` so a later session does not raise it again.

#### Write the compose file

On confirmation, write `docker-compose.yml` at the project root, in the layout `project-overview.md` recorded. Follow these rules, which exist because each one has bitten a real project:

1. **Every value that differs between machines is an environment variable with a default**, in the form `${DB_PORT:-5432}`. A fresh clone must come up with no `.env` file present.
2. **Every service another service waits on has a healthcheck**, and the waiting service uses `depends_on` with `condition: service_healthy`. A plain `depends_on` waits for the container to start, not for the service inside it to be ready, which is the usual cause of a backend that dies on first boot.
3. **A one shot setup container uses `condition: service_completed_successfully`**, for example the container that creates the storage bucket.
4. **Persistent data goes in a named volume**, declared at the bottom. Every declared volume is actually used by a service. An unused volume is a leftover.
5. **The network key and the network name match.** Declaring the key `my-network` while every service references `${NETWORK_NAME:-project-network}` only works because `name:` overrides the key, and it breaks the moment someone reads it. Use the same string for both.
6. **Source folders are bind mounted for live reload**, and the dependency folder is mounted separately so the host's copy does not shadow the container's.
7. **Secrets have obvious throwaway defaults** such as `minioadmin`, and the file says in a comment that they are for local development only. Never write a real credential into this file.

Then write the matching `.env.example` listing every variable the compose file reads, with its default. Never write `.env` itself.

#### Settle what happens to local data between tasks

Only when the stack has a data store. Ask, because both answers are reasonable and a build must never decide this on its own:

> "Between tasks, should the local database reset to a clean state, or keep its data?"

1. **Reset every task** (recommended when the schema is still moving): every task starts from a known state, migrations get exercised constantly, and nothing accumulates. The cost is retyping anything you were testing with.
2. **Keep it, with seed data**: a fixture set loads once and survives. Better once the schema settles, and much better when a realistic data set is needed to judge a UI.
3. **Keep it untouched**: whatever is in there stays. Simplest, and the most likely to drift into a state nobody can reproduce.

Record the answer, the exact reset command, and where any seed data lives in `tooling.md`'s Local Data Lifecycle section.

**A build never drops a local database on its own initiative.** Someone else's work in progress may be sitting in it, and there is no undo. That rule is in the template so it reaches whoever builds.

Record every service, its purpose, and its ports in `tooling.md`.

Writing this file is the one exception to the no code rule, because it is the structure the build sits in rather than the product itself. Do not write a `Dockerfile.dev`, and do not run `docker compose up`. `/dev-develop` does both.

### Step 6: Agent tooling discovery

Run this only once the stack is settled, and only for tools not already installed or already recorded as declined.

**Read `internal/tool-discovery.md` and follow it.** It holds the consent gate, the two registries, the candidate checks, and the recording rules.

The headline, so it is visible from here: **asking is mandatory, searching is not.** Nothing is searched, fetched, or installed until the user picks. And you can install a skill, but you **cannot** connect an MCP server for them, because that changes their own configuration.

Skip the file entirely when the stack walk chose no new tool.

### Step 6a: Doubt the decisions that are expensive to undo

Run this once the design conversation's completeness gate has passed and before a single document is written, on the few decisions a later skill cannot cheaply reverse.

**Read `internal/doubt-pass.md` and follow it.** It holds the trigger list, the brief for the doubter, how to sort what comes back, and the cap.

Three rules worth seeing from here. **Send the doubter the decision and what it must satisfy, and none of your reasoning**, because a reviewer given your argument reviews your argument and finds it coherent, which it is. **It writes nothing anywhere**, including `decision-log.md`, which is not this skill's file to write rows in.

And **each round spawns a subagent, so the user sets the cap.** Read the Doubt pass rounds section of `tooling.md`, and where it is empty ask once, recommending 3, then record the answer there so no later run asks again. Never ask per decision, and never raise the cap partway through a pass.

Skip the file when nothing this pass settled meets the trigger list. That is a normal outcome on a small project, and doubting an easily reversed choice costs an afternoon and buys nothing.

### Step 7: Write the Stage 1 documents

**Read `internal/standards.md` before writing `code-standards.md`.** It holds the convention questions, the four architecture style presets in `patterns/`, and the rule that an existing codebase gets its conventions derived from the code rather than recited from memory.

One file at a time, in order: `architecture.md`, `tooling.md`, `code-standards.md`, `library-docs.md`.

**Stamp every document you create.** End each one with a single line:

```
_Drafted by /dev-architect on <date>. Edited by hand since then, in part or whole, unless this line says otherwise._
```

This exists so a later run, here or in `/dev-sync`, can tell what a tool wrote from what a person wrote, **instead of guessing**. Without it, every skill that maintains these files is left inferring intent from prose style, which it will get wrong.

**The stamp records provenance, not permission.** It never licenses overwriting a line someone edited. A stamped file still gets the same care as an unstamped one.

**Write the round cap into `tooling.md`'s Doubt pass rounds section**, using the answer step 6a got, or `3` where no doubt pass ran and nothing was asked. That section is what stops a later run asking the same question again.

**Fill the Definition of Done in `code-standards.md` with this project's real commands**, not a generic list. It is the standing bar every later skill checks before stamping a task `DONE`, so a row reading "tests pass" on a project whose test command you never confirmed is worse than an empty table: it will be ticked from memory. Keep the section and its Not on this list subsection as the template has them, since the exclusions are what stop it growing into a gate that swallows `/dev-check` and `/dev-test`.

**`library-docs.md` is sourced, not recalled.** Read the version out of the project's manifest, fetch the docs page for that version, and put its URL and the date you read it on the section's Source line. Where you keep a note you could not verify, write the unverified shape the template gives rather than softening the note itself, since a hedge inside prose gets skimmed and a Source line does not. Keep the Where a note comes from section exactly as the template has it: `/dev-sync` and `/dev-develop` both read it, and a sourcing rule only holds while it is written down.

For each:

1. Read the template in full before writing.
2. Replace every bracketed placeholder with real content. No literal `<TOKEN>` survives. Check before presenting.
3. Follow the template's repeat instructions. One section per table, per language, per client, per library. Produce as many as the project needs.
4. Keep a section marked Optional only when it genuinely applies. Remove it otherwise and say which you removed and why. Never present an empty section as a placeholder.
5. **Delete every section marked Reference only**, meaning the Worked example at the end of `progress-tracker.md` and `decision-log.md`. Read it, then leave it out of the file you write. Its content is invented, and invented tasks, names, and dates left in a real document send the next session looking for work nobody did.
6. Present the file, get approval, then start the next. If a change contradicts an earlier file, go back and fix that file too.

### Step 8: Write the Stage 2 documents

Only after every Stage 1 artifact is approved. Same per file process, in order: `build-plan.md`, `progress-tracker.md`, `decision-log.md`, `ui-registry.md`.

Extra rules:

- `build-plan.md` writes the history line step 2a settled, on an existing codebase: either `## Phase 0 — Already built` with one task per existing feature, or no Phase 0 at all, plus the one line under Core Principle that says which it is. `internal/adoption-baseline.md` has the wording. On a fresh project neither applies.
- `build-plan.md` covers every feature in the Features in Scope list and nothing from the out of scope list. Its Feature Count table must match the number of tasks actually written. Order the phases so each one is visible and testable before the next starts.
- Every task in `build-plan.md` has one plain Goal sentence and checkable UI and/or Logic subtask goals. Build a coverage list from the Stack table, System Boundaries, data flow, Invariants, Security model, Value Sourcing table, and operator duties in `architecture.md`. Assign every build affecting commitment to at least one task. **Use its exact approved name in every task that establishes or relies on it.** A generic phrase does not cover a named runtime, service, protocol, boundary, or invariant. This is what keeps a lower reasoning builder from losing an architecture decision between files.
- `progress-tracker.md` mirrors `build-plan.md` exactly, one Progress table per phase. Every task gets one aggregate row carrying its number, name, and Goal, followed by one child row per UI and Logic subtask goal in plan order. Never summarize or combine them. A Phase 0 in the plan gets its Progress table here too, every aggregate and child row reading `BASELINE` with its three line stamp and an empty Verify Check. **Never `DONE` and never a Verify Check on one of those rows**: nothing was built here and nothing was exercised, and `progress-tracker.md` defines the difference. Every other aggregate and child row reads `PENDING` with no stamp, an empty Verify Check and Note written as `—`, Last completed reads "nothing yet", and Next names the first task and its first child outside Phase 0. **Never stamp a `PENDING` row.** A stamp names a value, model, and minute on separate rendered lines, and nothing has been built yet. A `BASELINE` row is stamped, and that file's Status section says what its stamp means. Its Worked example section is Reference only: read it for the shape, and delete it from the file you write.
- `decision-log.md` always ships, and always starts with its headings and an empty Entries table. Nothing has been decided or observed during a build that has not started, so a row here would be invented history. Keep the Entries and Who writes what sections exactly as the template has them, and delete the Worked example.

**Team Shape decides the shape of these.** Read that section in `project-overview.md` before writing any of them, and follow it exactly rather than deciding for yourself. `/dev-scope` asked the user, and this is where their answer takes effect.

**Mode is `team`:**

- Every aggregate task row in `progress-tracker.md` keeps its Assigned column and reads `unassigned`. Every child row reads `inherits task`. Never fill in a name here. Nobody has picked up a task yet, and an assignee you invented would send someone to the wrong person.
- `decision-log.md` keeps its Actor column. Its Author column stays either way, since the model varies between sessions even when the person does not.
- Say plainly in your handoff that the assignee is a convention rather than a lock, so nobody reads the column as a reservation the system enforces. It does not, and cannot.

**Mode is `personal`:** drop the Assigned column from every Progress table in `progress-tracker.md`, including both aggregate and child rows, and delete the Actor column from `decision-log.md` along with its description. One person means one repeated value, and a column with one value is noise. **Keep the Author column.** The person is fixed on a personal project and the model is not.

- `ui-registry.md` is skipped when the project has no component based UI layer, the same condition under which `code-standards.md` has no Component Structure section. Say you skipped it rather than writing an empty file. On a fresh project with a UI layer it starts empty apart from its heading, since no component exists yet.

### Step 9: Check, cross check, and confirm

**Read `internal/after-writing.md` and follow it**, once the documents exist.

It covers confirming the write landed, checking your own work for blank fields, offering a cross check on a different model, and the acceptance loop. Its two rules that matter most: **always ask about the cross check rather than running or skipping it yourself**, and **never silently resolve a gap it finds**, because each one is a load bearing decision that belongs to the user.

### Step 10: Report

Say all of this:

- The files written, including `docker-compose.yml` and `.env.example` if step 5 wrote them.
- The optional sections and files skipped, and why.
- Every container in the compose file, its purpose, and the port it is on. Name any stand in service and the real service it stands in for. State what happens to local data between tasks.
- **Every security finding from the dependency audit**, with its severity and whether the fix became a task. If the user declined an update, say so plainly here as well as recording it, so an accepted risk stays visible.
- **The adoption baseline, on an existing codebase**: where the history line landed and what it does not exempt. Say the exemptions out loud, because a user who took the default is usually picturing a wider amnesty than they got. Say too that `/dev-design` will ask a separate question about the surfaces.
- Every skill installed, by name.
- Every MCP server the user still needs to connect themselves, with the exact command.
- Every human decision recorded during this run where the selected option was not the recommended option, by ID and subject.
- That no application code was written.

Then name the next step: a separate request to build the first task in `build-plan.md`. **Where the plan has a Phase 0 of baseline rows, name the first task after it**, since nothing in Phase 0 is work anybody is going to do.

---

## Reference files

All of these live in this skill's folder, read only when you reach them.

- `internal/adoption-baseline.md`: the history line, meaning whether features already built appear in the plan, and what the baseline does not exempt. Read at step 2a, existing codebases only. The design line is `/dev-design`'s.
- `internal/brownfield-audit.md`: the structure confirmation, the existing component decision, and the dependency audit. Read at step 4, existing codebases only.
- `internal/standards.md`: the convention and tooling questions that fill `code-standards.md`, and how to derive conventions from an existing codebase. Read at step 7.
- `patterns/*.md`: the four architecture style presets. Read only the one the user picks, at write time.
- `internal/stack-defaults.md`: the architecture pattern table, the durable category per layer, and the opinions to apply. Read during the stack walk in step 2.
- `internal/after-writing.md`: the self check, the cross check offer, the acceptance loop, and the closing summary. Read at step 9, never earlier.
- `internal/judgment.md`: the posture, the known failure patterns, the challenge the premise step, and the rules that hold across every decision. **Read in full before step 2**, alongside the conversation protocol.
- `internal/design-conversation.md`: the interview protocol. The already built check, framing, the dimension checklist, question mechanics, the six stages, and the completeness gate. **Read in full before step 2**, and it is a hard gate, not a suggestion.
- `internal/tool-discovery.md`: the skill and MCP consent gate, the two registries, the candidate checks, and how each kind is set up. Read at step 6, and only when the stack walk chose a new tool.
- `internal/doubt-pass.md`: the trigger list, the adversarial brief, how to sort the findings, and the three round cap. Read at step 6a, and only for a decision that is expensive to undo.
