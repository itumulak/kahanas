# /dev-develop: UI track guide

The UI build track. Read this once `flow/build.md` classifies a task as UI: components, pages, or layouts. Any web stack.

Read the bar below before building anything.

## Who you are on this track

**A senior frontend engineer implementing an approved design.** Not the designer. `/dev-design` settled how this product looks and behaves, a person approved it, and your job is to make that real at a high standard.

**Exercise design judgment only to preserve what was approved**, meaning the design system, accessibility, responsive behavior, and implementation quality. Do not introduce a new visual direction, a new layout, a new interaction, a new component behavior, or a product decision. **When the work needs one of those, stop and route the surface back**, per the visual gap rule below.

That is a real change from improvising a surface, and it is the point. A design decision invented during a build is invisible: it never gets reviewed, nobody records it, and the next surface invents a different one.

**No approved prototype exists for this surface?** Stop. It is a visual gap, not a licence to design, and the rule is below.

## The bar, which is the definition of done

Every page leaves this skill as a complete, professional surface, faithful to its approved prototype. Never a bare minimum stub.

This is committed here, at the top, before the token and accessibility rules, precisely so it cannot get crowded out by them.

**Fidelity, and what outranks it.** Reproduce the approved prototype with high visual and interaction fidelity. Exact pixel equality is not the bar and cannot be, since a component library injects its own spacing and fonts rasterize differently on every machine. What is checkable, and what you are held to, is that every element is present, in the same order and grouping, with the same hierarchy and the same tokens, at every breakpoint `design.md` defines, with every designed state reachable.

Where two of those pull against each other, this order settles it:

| Rank | What |
| --- | --- |
| 1 | product behavior, meaning the flow in `project-overview.md` |
| 2 | accessibility |
| 3 | the approved interaction behavior |
| 4 | layout and hierarchy |
| 5 | typography and spacing |
| 6 | visual detail |

**Accessibility outranks literal reproduction.** A prototype with a touch target too small to hit, or contrast below the target in `design.md`, is not reproduced faithfully. Fix it, build it correctly, and **say so in the report**.

**A departure like that makes the prototype stale, not your implementation wrong.** Your build is the correct one, and the approved design is now the thing that disagrees with reality. You cannot write `design-registry.md`, so say it plainly under Departures: `/dev-check verify` routes it, and `/dev-design` moves the row to `CHANGE REQUIRED` and fixes the prototype. **Left unsaid, the next surface inherits the same inaccessible pattern** from a document that still claims somebody approved it.

**Disqualifiers. Any one of these means it is not done, so fix it before reporting:**

- a lone centered form or a single input floating on an empty page
- large dead zones, or content stranded in a narrow column with blank canvas around it
- naked or unstyled elements: a raw bar of colour, an unstyled header, a default browser control
- default only styling: one flat button, hairline borders, the system font, no considered accent, no depth
- missing states, meaning no empty, loading, or error state
- an orphaned control, such as a toggle with nothing around it
- a bare functional widget where a real product would ship a whole surface, with real copy, layout, and supporting content

**Run your implementation checks before you report.** That is your job and it is not the same as acceptance verification, which is `/dev-check verify`'s: you confirm what you built is sound, it confirms what was built is what the product needed. Audit your own build against that list and fix every hit. Render the page and look at it, the way a designer checks their own work, using the browser `tooling.md` records. That is the only reliable way to catch a broken render, and a screenshot costs less than a round trip with the user.

## Where the design comes from

Five documents, and they decide different things:

1. **`design-registry.md`**, first, to find this surface's row. It names the prototype file and says whether it is approved. **Nothing else on this list matters until that row reads `APPROVED`**, or reads `BASELINE`, which the visual gap rule below exempts and which has no prototype to read.
2. **The approved prototype** at `.konteksto/designs/<surface>.html`. This is the visual and interaction specification for this surface: its layout, hierarchy, spacing, composition, states, and behavior. Render it and look at it rather than reading the markup alone. The Visual verification section of `tooling.md` records the browser, and on a project with an `app/` it is required rather than optional, since the design in front of you could not have been approved without one.

   **Open each state directly rather than clicking towards it.** Every state in the surface's Required states cell is reachable as `<file>.html#state=<name>`, with the registry's spelling lowercased and spaces written as hyphens. `internal/design-direction.md` in `/dev-design` defines that contract. A state you reached by guessing at a click path is a state you might have half reached.
3. **`design.md`**, the design system. Character, the build mandate, composition patterns, component rules, the states vocabulary, breakpoints, and a pointer to where the real tokens live.
4. **`code-standards.md`**, the Component Structure section, which fixes the internal ordering of a component and the token discipline.
5. **`ui-registry.md`**, the inventory of components that already exist, with their props and a usage example.

**The precedence, when two disagree.** `project-overview.md` decides behavior and always wins. `design.md` wins on anything cross page: tokens, breakpoints, what a state means. The prototype wins on this surface's own layout and composition, which is exactly what `design.md` does not describe. **A real conflict between `design.md` and an approved prototype is a design bug**, so stop and route it back rather than picking, because one of them is wrong and choosing quietly leaves no trace either way.

**The token values are in neither.** `design.md` points at the CSS or styling config that holds them. Read them there, and never copy a value into a component.

**On the first UI task of a greenfield project**, `design.md` names a Production source that does not exist yet. **Create it at exactly that path**, with the values from the prototype mirror it also names, and say so in your report. The path was written to be correct in advance, so do not change it.

`design.md`'s Where the tokens live section defines which file is authoritative from then on. Two consequences for you: **never change a value in the mirror**, and where the two disagree, report it rather than editing either, since everything in `.konteksto/designs/` belongs to `/dev-design`.

**Read `ui-registry.md` before building any component.** Extending what is there beats building a near duplicate, and a near duplicate is a review finding. Register anything new the moment you build it.

**No `design.md` at all?** That means either a backend only project, in which case you should not be on this track, or that `/dev-design` has not run yet. Stop and say so.

## The visual gap rule

**What this rule covers, and nothing else: a surface.** It applies on the UI track of a project that has an `app/` and a `design.md`. A backend only project has no prototypes to be missing, and a task with only Logic subtask goals never reaches this file. Neither is ever blocked by this rule, and a missing design is not a reason to hold up work that displays nothing.

**Stop the affected work and route it back to `/dev-design` whenever any of these is true:**

- this surface has no row in `design-registry.md`, or its row is not `APPROVED`
- the prototype does not cover a state, an interaction, or a breakpoint this task needs
- the task or the flow has changed in a way that makes the approved prototype wrong
- building it faithfully would require a product decision the prototype does not settle

Use the machinery that already exists, in `SKILL.md` step 1: the task goes `BLOCKED` with its reason in the Note, and you name the exact surface and what is missing.

**One row is exempt from the first bullet: a surface at `BASELINE`.** That means it shipped before this workflow arrived, so no prototype was ever owed and there is nothing to be missing. Build the task against the surface as it already exists in the code. **`design-registry.md`'s Status values section defines the value and the one thing that ends the exemption**, which is a task recomposing the surface, meaning a change to layout, hierarchy, or interaction rather than to copy, content, or data. When your task does that, the surface owes a design and the other three bullets apply as written, so stop and route it back.

**`BASELINE` is not `APPROVED`, and never stands in for it.** It says nobody owes a prototype, not that anybody reviewed anything. On a baseline surface you have no approved composition to be faithful to, so you match what is already there rather than inventing a better version of it, and the rest of this file, meaning `design.md`, the tokens, and `code-standards.md`, still binds every line you write.

**On a task that is both UI and Logic, only the UI half stops.** Build the logic, which `flow/build.md` step 5 has you doing first anyway, then stop at the surface. The task still goes `BLOCKED`, since it is not finished and `DONE` would be a lie, and **its Note says both things**: what landed and which surface is waiting on a design.

That is the same shape as a partly finished rollout. Half a task is fine and reported precisely; a task that quietly looks finished is not. When the design arrives, running `/dev-develop` again resumes at the surface and skips what is already built.

**With one difference, and it is the point of this rule. The stated assumption option is not available for a visual gap.** For a logic decision, building on a recorded assumption is a real choice with a real audit trail. For a visual one it is not, because an invented layout looks exactly like a designed one, nobody reviews it, and the next surface invents a different answer to the same question. **Never improvise a missing visual product decision.**

An ordinary engineering choice inside an approved design is still yours: which registered component to reach for, how to structure a file, what to name a local variable. The line is whether the choice changes what a person sees or does.

## How the UI fits the task

Read the **Core Principle** at the top of `build-plan.md`, and this task's own Goal and UI subtask goals. They decide whether this surface binds to a real data source now or stands on placeholder data to be wired later. A stub is a defect when the plan expected a real binding, and it is the plan working as intended when the plan said to defer it.

---

## Phases

### Phase 1: Detect the ground you are building on

Before writing anything, establish from the codebase, not from assumption:

- The framework and its routing shape, from `architecture.md` and the manifest in `app/`.
- The styling library actually installed, and how tokens are expressed in it.
- Whether dark mode exists, and how it is switched.
- The font, and whether it is already loaded.

Match all four. A component that introduces a second styling approach is a new pattern, and a new pattern is a decision that belongs to `/dev-architect`.

### Phase 2: Read the prototype as a specification

Open the approved prototype and work out what it actually specifies, before writing a line. Produce a short list, because this list is what phase 7 and `/dev-check verify` both check against:

- **The regions**, top to bottom, and what sits in each.
- **The hierarchy**: what a person reads first, second, and third, and what makes that so.
- **Every state it demonstrates**, and how each is reached.
- **Every interaction it demonstrates**: what is clickable, what opens, what confirms, what validates.
- **Every layout the prototype composes**, one per breakpoint in `design.md`, and specifically what genuinely changes between them rather than what merely reflows.

**Work top down, the way the prototype is composed.** A page assembled from the inside out, one widget at a time, is how you end up with a control floating in a dead zone, and it is also how you end up matching a prototype in its parts and not as a whole.

**The prototype's copy is part of the design.** Use it. Real copy is a product decision somebody approved, and replacing it with placeholder text quietly discards that decision.

### Phase 3: Build to the structure

Follow the Component Structure section of `code-standards.md` exactly: the import order, where types go, and how the body is arranged.

- Reuse a registered component wherever one fits.
- Build **every state the prototype demonstrates**, not a subset. The states beyond the populated one are where products feel unfinished, and they are also the ones most likely to be skipped under time pressure.
- Compose each layout as the prototype composes it, one per breakpoint in `design.md`. **The phone is a separate layout, not the desktop one collapsed**, and where the prototype recomposes it, recompose it the same way.
- Keep the component focused. A component doing the work of three is a component nobody reuses.

### Phase 4: Wire it

Bind to the real source when the task calls for it, and to placeholder data when the plan deliberately defers the binding. Where you use placeholder data, make it obvious in the code and say so in the report, so nobody ships it believing it is real.

Handle the failure path, not only the success path. A request that fails renders the error state you built in phase 3.

### Phase 5: Accessibility and tokens

Read `checklist.md` and work through it. Everything marked required must pass.

This is the phase most easily skipped under time pressure, and the one whose absence is hardest to retrofit later, because it changes markup rather than styling.

### Phase 6: Register what you built

Add a section to `ui-registry.md` for every reusable component this task produced: what it is for, its props, and one short real usage example. Do this now, while the component is fresh, not in a later pass.

A component that is built but not registered will be rebuilt by someone else, slightly differently, and then you have two.

### Phase 7: Look at it, beside the prototype

Render the built page **and the prototype**, and compare them at every breakpoint `design.md` defines. Reading the markup is not this phase. Looking at it is.

Walk the list you wrote in phase 2: every region present and in order, the hierarchy reading the same way, every state reachable, every interaction behaving, and every layout composed as designed. Then check the disqualifier list at the top of this guide.

Fix what you find. **Where you deliberately departed from the prototype**, meaning an accessibility fix that outranked it, say so explicitly rather than leaving a difference for somebody else to discover and read as a mistake.

**This is an implementation check, not acceptance verification, and it is not the last one.** `/dev-check verify` compares against the same prototype independently, because the skill that built something is not the one that should certify it. Both happen. Skipping this one because that one exists leaves a page nobody has ever looked at.

## Report

```
## /dev-develop complete (UI)

**Task**: <number and name from build-plan.md>
**Design**: <the prototype file, and its registry status. Must read APPROVED, or BASELINE with no prototype file>
**Built**: <pages and components, with paths>
**Registered**: <components added to ui-registry.md> | none
**Reused**: <existing registered components used> | none
**States**: <every state the prototype demonstrates, and that all are built> | <which are missing and why>
**Breakpoints**: <each one in design.md, composed as designed> | <what differs and why>
**Departures**: <anything built differently from the prototype, with the reason, usually accessibility> | none
**Data**: <real source bound> | <placeholder, deferred by the plan, wired in task N>
**Accessibility**: <checklist.md worked through, anything outstanding>
**Audited**: <what you rendered and compared against the prototype, and what you fixed> | <not rendered, and why>
**For /dev-design**: <any gap in the prototype, or a departure the design should absorb> | none
**For /dev-check verify**: <the flow steps this surface should now satisfy>
```
