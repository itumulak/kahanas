---
name: dev-context
allowed-tools: Bash, Read, Grep, Glob
argument-hint: [task]
description: "Run /dev-context to establish project context before development, verification, or a handoff. Reads the project records in their required order, including the person's recorded choices and recommendation overrides, identifies the active task and governing decisions, then follows their ownership and workflow rules."
---

## Output style (plain words, no dashes, no hyphens)

<!-- OUTPUT-STYLE:START -->
Write everything this skill produces, files and messages alike, in plain simple language. Keep technical terms that carry real meaning; explain each in plain words. Never use a dash or a hyphen as punctuation: no em dash, no en dash, and no hyphenated compounds. Write `read only`, not `read-only`. Say it in simple words, or reword the sentence. Code, file paths, command flags, and values other skills match on keep their hyphens. A structural separator inside a template format other skills parse, such as the em dash in `## Phase 1 — <NAME>`, is part of that format: reproduce it exactly, since changing it breaks the mirroring. Use short sentences, commas, or parentheses. Clear beats clever.
<!-- OUTPUT-STYLE:END -->

## What this skill does

The context entry point for a fresh agent or a task that needs a complete project view. It reads the project records in a fixed order, so the plan, current state, and documented decisions are interpreted against the architecture and standards that govern them. It prepares a session; it does not replace the narrower records each delivery skill must read for its own work.

This skill is read only. It does not repair stale documents or change code. Report contradictions with the document and owner that must resolve them.

## Read in this order

Read each existing item completely before moving to the next:

1. `.konteksto/project-overview.md`
2. `.konteksto/glossary.md`
3. `.konteksto/human-decisions.md`
4. `.konteksto/architecture.md`
5. `.konteksto/tooling.md`
6. `.konteksto/code-standards.md`
7. `.konteksto/library-docs.md`
8. `.konteksto/build-plan.md`
9. `.konteksto/progress-tracker.md`
10. `.konteksto/decision-log.md`
11. `.konteksto/audit-register.md`, when it exists, because unresolved findings constrain the active task before its component inventory is read
12. `.konteksto/ui-registry.md`
13. The approved design, as identified by `build-plan.md` or the design registry.

If a required record is absent, do not invent it. State which record is missing and use the owning workflow to resolve it. If no approved design applies to the active task, say so and route UI work to `/dev-design`.

## Establish the active context

After reading, identify:

- the project shape, runtime, and verification commands
- the active or next task, its Goal and subtask goals, its dependencies, and its progress and verification state
- the decisions and terminology that constrain that task
- the human choices that departed from the recommendation presented, especially any that govern the active task
- open audit findings and any QA regressions that affect that task
- the approved design surface, when the task has UI work
- document ownership and the next valid workflow step

Read `.konteksto/loop-state.md` after the required records when it exists. It is supplemental execution state, not a replacement for the progress tracker. When it describes an active run, its Next action is the current workflow instruction; report it verbatim rather than deriving a competing next step.

## Apply the protocols

Follow the ownership, approval, and routing rules recorded in the documents. In particular:

- Build only the active task and do not make load bearing decisions without the documented owner.
- Confirm the aggregate task row reproduces the task number, title, and Goal from `build-plan.md`, and that every UI and Logic subtask has its own child row in plan order with its goal copied word for word. Report any missing, extra, combined, reordered, or reworded row as stale planning owned by `/dev-architect`.
- Treat a `DONE` status as a build claim, not acceptance proof. A `PASSED` Verify Check is the observed runtime signal.
- Do not edit records owned by another workflow merely to remove a contradiction.
- Preserve the approved design boundary for UI work.

Finish with a concise context brief: active aggregate task, first unfinished subtask, all task and subtask goals, current phase, governing constraints, applicable design, blockers, and next valid skill. Do not claim verification or approval that the records do not support.
