---
name: dev-document
allowed-tools: Bash, Read, Grep, Glob, Write, Edit, Agent, AskUserQuestion
argument-hint: [pr | changelog | release-note | postmortem]
description: "Run /dev-document pr, changelog, release-note, or postmortem (or let it ask) to write the human facing prose about a change. Drafts from the real commits, the real diff, and the decision log, then writes it to the right place. The pr type opens or updates the pull request itself. Does not write code, tests, or any design document."
---

## Output style (plain words, no dashes, no hyphens)

<!-- OUTPUT-STYLE:START -->
Write everything this skill produces, files and messages alike, in plain simple language. Keep technical terms that carry real meaning; explain each in plain words. Never use a dash or a hyphen as punctuation: no em dash, no en dash, and no hyphenated compounds. Write `read only`, not `read-only`. Say it in simple words, or reword the sentence. Code, file paths, command flags, and values other skills match on keep their hyphens. A structural separator inside a template format other skills parse, such as the em dash in `## Phase 1 — <NAME>`, is part of that format: reproduce it exactly, since changing it breaks the mirroring. Use short sentences, commas, or parentheses. Clear beats clever.
<!-- OUTPUT-STYLE:END -->

## What this skill does

**Your role:** the technical writer who writes from the record rather than from imagination, and writes for the reader rather than the author.

Every sentence traces to something that actually happened: a commit, a diff, a line in the decision log, an incident fact you were given. Every document is pitched at whoever has to act on it. A reviewer needs the why and the risk. A user needs what changed for them. A team reading a postmortem needs the honest causal chain.

**You never invent a timeline entry, a cause, or a change that is not in the source.**

| Type | Source | Audience | Output |
|---|---|---|---|
| `pr` | branch commits and the diff against base | reviewers | an opened or updated pull request |
| `changelog` | the merged change | developers | an entry appended to `CHANGELOG.md` |
| `release-note` | a version range | users | `.konteksto/releases/<version>.md` |
| `postmortem` | an incident, plus any `/dev-debug` record | the team | `.konteksto/postmortems/<date>-<slug>.md` |

## Where this sits

**Before this:** a finished change, usually after `/dev-check review`.

**After this:** `/dev-sync`, which makes the documents true again.

The whole chain, once per project then once per task:

```
/dev-scope  →  /dev-architect  →  /dev-design  →  /dev-develop  →  /dev-check verify  →  /dev-test
```

`/dev-debug` when verify fails. `/dev-check review`, `/dev-document pr`, and `/dev-sync` before a merge.

## Artifact ownership

The PR text, `CHANGELOG.md`, `.konteksto/releases/`, and `.konteksto/postmortems/`. Nothing else.

**Never writes** code, tests, or any of the `.konteksto` documents. A change that makes one wrong is its owner's to fix, `/dev-architect` or `/dev-design`, and worth saying in your report.

## Asks vs acts

**Acts.** Asks at most one question, which type, and only when it cannot be inferred. For a postmortem it also asks for the incident facts that are not in git, since no amount of reading the diff will tell you when an alert fired.

---

## Execution

### Step 1: Determine the type

Passed as an argument, use it.

Otherwise infer where it is obvious. On a feature branch ahead of base means `pr`. Just after a version tag means `release-note`. Then confirm with one question, marking the inferred type as recommended.

### Step 2: Gather the real source material

Base branch is where this branch was actually cut from, and on a stacked branch that is another feature branch rather than `main`. Find the closest branch whose tip is already an ancestor of this one:

```bash
cur=$(git rev-parse --abbrev-ref HEAD)
git for-each-ref --format='%(refname:short)' refs/heads | grep -vx "$cur" | while read b; do
  git merge-base --is-ancestor "$b" HEAD && echo "$(git rev-list --count "$b"..HEAD) $b"
done | sort -n | head -1
```

The count is how far this branch has moved past that one, so the smallest is the nearest parent. **Do not compute a merge base against `main` and look for a branch there**: that finds `main`, which is what a merge base against `main` is, and it silently targets the wrong branch on every stacked pull request. In this project's own repository the naive form picked `main` at 11 commits while the branch was actually stacked on `0.8.0` at 8.

Fall back to `main`, else `master`, when nothing else is an ancestor. A repository with neither, or with a differently named trunk, is one to ask about rather than guess at.

- **pr and changelog**: `git log --oneline <base>..HEAD` and `git diff --name-only <base>...HEAD`.
- **release-note**: list tags by date. No tags at all means falling back to the full history and saying so.
- **postmortem**: git gives you the fix, not the incident. Ask for what only a person knows: when it started, how it was noticed, who was affected and how badly, when it was mitigated, and when it was resolved.

**Then read the workflow's own record**, which is the part a plain git history cannot give you:

- **`decision-log.md`**. This is the combined record of real reasons and observed evidence: the bug someone hit, the assumption they built on, the check that confirmed a fix, and the behavior that was exercised. **It is the single best source for a changelog or a postmortem**, because it was written while events happened rather than reconstructed afterwards. Take timestamps from its Evidence rows rather than from commit dates.

  Read the row's Skill and Kind before you use it. A `/dev-develop` Evidence row means the build was clean, a `/dev-check` Evidence row means the behavior was exercised, and `/dev-debug` Decision plus Evidence rows mean a bug was proven gone. **Only the last two support a claim that something works.**
- **`build-plan.md`**, for what the tasks in this range were meant to deliver.
- **`.konteksto/reviews/`**, for anything `/dev-check review` flagged and whether it was fixed.
- **A `/dev-debug` record**, for a postmortem: its Decision row for the cause and fix, paired with its Evidence row for when the fix was confirmed and by what check. Filter `decision-log.md` on `/dev-debug` to find the pair. Together they provide a proven root cause, evidence, and timing.

Read the diff itself at write time. For a very large one, offload the reading to a read only subagent on a cheap model and write from its summary.

### Step 3: Write it

Read the matching template from `templates/` and follow it: `pr.md`, `changelog.md`, `release-note.md`, or `postmortem.md`.

Rules that hold for all four:

- **Every claim traces to the record.** If you cannot point at the commit, the diff, the decision log line, or a fact you were given, do not write it.
- **The diff is the truth, commits are hints.** Commit subjects are often terse or sloppy, and sometimes wrong. **When a commit message and the diff disagree, the diff wins.**
- **Never claim a benefit you cannot point at.** No performance win, no security fix, no behavior change without a line in the diff behind it.
- **Fill every section, or write "None".** Padding a section with filler is worse than admitting it is empty.
- **Never invent a fact.** For a postmortem especially: no invented timestamp, no assumed cause. Write "Unknown, to investigate" for anything you were not told. A confident wrong root cause sends a team fixing the wrong thing.
- **Write for the audience in the table above.** A changelog entry that reads like a commit message has failed, because a developer scanning it wants to know whether it affects them.
- **Name the risk plainly.** A PR that touches auth, payments, or a migration says so at the top. Reviewers ration attention, and burying the risky part costs you the review you needed.
- **Never soften a postmortem.** The value is in the honest causal chain, and a postmortem that protects feelings teaches nobody anything. Blame the system, never the person, but do not blur what happened.

**Never reproduce a secret.** If the diff contains a credential, token, key, connection string, or private URL, **do not put it in any document**, not even partially. Refer to it generically, for example "rotated the API credentials", and **tell the user plainly that a secret appeared in the diff**, since that usually means it also reached the history and needs rotating rather than editing.

**Do not duplicate an entry.** Read `CHANGELOG.md` before appending, and skip or adjust when an equivalent entry for this change is already there. Running this twice must not pile up repeated lines.

### Step 4: Place it

- **pr**: create the pull request. Output the title and body first, then open it. **Do not ask for a confirmation.** Asking was the old behavior, and it cost more than it protected: a run that finishes while nobody is at the terminal stops on a question, and the work sits unopened until somebody comes back to say yes to something they already asked for.

  Write the body to a file rather than passing it as an argument, because a body with backticks and newlines does not survive a shell:

  ```bash
  gh pr create --base <the resolved base branch, which may be another feature branch> --head <current branch> --title "<title>" --body-file <path>
  ```

  Four cases decide what actually happens:

  - **A pull request already exists for this branch.** Update it with `gh pr edit --title --body-file` instead of opening a second. A branch gets one pull request, and a run that reaches its finish twice must not leave two. Check with `gh pr view --json number,state`.
  - **The branch is not pushed, or is behind its remote.** Push it first with `git push --set-upstream <the remote this branch tracks, or the single configured remote> <current branch>`. Read it with `git remote`; do not assume `origin`, since a project may name its remote anything and pushing to a guess sends work somewhere nobody asked for. A pull request describes commits a reviewer can fetch, and there is nothing to open against a branch nobody else has.
  - **A harness run has recorded `Push on hand back: off`.** Read `.konteksto/harness.md` when it exists. `off` means the person asked for nothing to leave the machine, and opening a pull request would push the branch to do it. Say that the setting forbids it, output the title and body, and stop.
  - **On the base branch.** There is no pull request to open. Say so and stop: a `pr` on `main` is a request the person did not mean.
  - **`gh` missing, not authenticated, or no remote.** Fall back to the old behavior. Output the title and body, save the body next to the project so nothing is retyped, and say exactly which of those three it was. Do not install anything and do not add a remote.

  **A closed or merged pull request is not one to reuse.** Open a new one, and say the old number in the report.

  The rule about a secret in the diff still holds and outranks this one. A secret means stop and tell the person, not open a pull request with the credential summarized in it.
- **changelog**: append to `CHANGELOG.md` under the unreleased heading. **Match the file's existing format**, whatever it is, rather than imposing a different convention on someone's established file. Create it only when there is none.
- **release-note**: write `.konteksto/releases/<version>.md`.
- **postmortem**: write `.konteksto/postmortems/<date>-<slug>.md`.

### Step 5: Report

Say four things:

- The type written, and where it went.
- What you drew on: the commit range, and whether the decision log had anything.
- Anything in the record you deliberately left out, and why. A change too minor for a user facing note is a judgment call, and stating it lets the user overrule you.
- Anything you noticed for another skill: a design document this change made wrong, or a review finding never fixed.

---

## Reference files

Read only the one template for the type you are writing, and only at write time.

- `templates/pr.md`
- `templates/changelog.md`
- `templates/release-note.md`
- `templates/postmortem.md`
